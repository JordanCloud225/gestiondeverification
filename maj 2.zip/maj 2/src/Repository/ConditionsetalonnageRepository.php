<?php

namespace App\Repository;

use App\Entity\Conditionsetalonnage;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Conditionsetalonnage>
 */
class ConditionsetalonnageRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Conditionsetalonnage::class);
    }

    //    /**
    //     * @return Conditionsetalonnage[] Returns an array of Conditionsetalonnage objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('c')
    //            ->andWhere('c.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('c.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Conditionsetalonnage
    //    {
    //        return $this->createQueryBuilder('c')
    //            ->andWhere('c.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
    public function findbydeletedAt($ide): ?QueryBuilder
    {
        return $this->createQueryBuilder('c')
        ->andWhere('c.deletedAt IS NULL')
        ->andWhere('c.identreprise = :ide')
        ->setParameter('ide', $ide)
        ->orderBy('c.norme', 'ASC')
        ;
    }
}
