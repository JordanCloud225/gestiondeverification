<?php

namespace App\Repository;

use App\Entity\Tolerance;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\QueryBuilder;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Tolerance>
 */
class ToleranceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Tolerance::class);
    }

    //    /**
    //     * @return Tolerance[] Returns an array of Tolerance objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('t')
    //            ->andWhere('t.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('t.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Tolerance
    //    {
    //        return $this->createQueryBuilder('t')
    //            ->andWhere('t.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
    public function findbydeletedAt($ide): ?QueryBuilder
    {
        return $this->createQueryBuilder('t')
        ->andWhere('t.deletedAt IS NULL')
        ->andWhere('t.identreprise = :ide')
        ->setParameter('ide', $ide)
        ->orderBy('t.valeur', 'ASC')
        ;
    }
}
